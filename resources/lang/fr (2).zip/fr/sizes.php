<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Home Page Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    '650mm (W) * 1150mm (L)' => '650mm (W) * 1150mm (L)',
    '700mm (W) * 950mm (L)' => '700mm (W) * 950mm (L)',
    'Customization' => 'Customization',
    'Ecotact Sterile 20  522mm(W) x 720mm(L)' => 'Ecotact Sterile 20  522mm(W) x 720mm(L)',
    'Ecotact 0.2  130mm(W) x 170mm(L)x Gusset [25mm+25mm]' => 'Ecotact 0.2 130mm(W) x 170mm(L)x Gousset [25mm+25mm]',
    'Ecotact 0.5  150mm(W) x 245mm(L)x Gusset [35mm+35mm]' => 'Ecotact 0.5  150mm(W) x 245mm(L)x Gousset [35mm+35mm]',
    'Ecotact 1.0 180mm(W) x 267mm(L)x Gusset [45mm+45mm]' => 'Ecotact 1.0 180mm(W) x 267mm(L)x Gousset [45mm+45mm]',
    'Ecotact 2.0  220mm(W) x 400mm(L)x Gusset [45mm+45mm]' => 'Ecotact 2.0  220mm(W) x 400mm(L)x Gousset [45mm+45mm]',
    'Ecotact 5.0  295mm(W) x 435mm(L)x Gusset [60mm+60mm]' => 'Ecotact 5.0  295mm(W) x 435mm(L)x Gousset [60mm+60mm]',
    '500mm(W) x 620mm(L)' => '500mm(W) x 620mm(L)',
    'Ecotact 25  558mm (W) x 810mm (L)' => 'Ecotact 25  558mm (W) x 810mm (L)',
    'Ecotact 40+  650mm (W) x 900mm (L)' => 'Ecotact 40+  650mm (W) x 900mm (L)',
    'Ecotact 40 558mm(W) x 939mm(L)' => 'Ecotact 40 558mm(W) x 939mm(L)',
    'Ecotact 50 650mm (W) x 1150mm (L)' => 'Ecotact 50 650mm (W) x 1150mm (L)',
    'Ecotact 80 762mm (W) x 1270mm (L)' => 'Ecotact 80 762mm (W) x 1270mm (L)',
    'HIGH QUALITY CORRUGATED BOXES 360mm (L)* x 295mm (W)* x 435mm (H)' => 'BOÎTES ONDULÉ DE HAUTE QUALITÉ 360mm (L)* x 295mm (W)* x 435mm (H)',
    'ECOTACT METAL DETECTABLE CABLE TIES 204mm (L) X 4.8mm (W)' => 'COLLIERS DE CÂBLES DÉTECTABLES EN MÉTAL ECOTACT 204mm (L) X 4.8mm (W)',
    'ECOTACT SUPERGREEN 40 545mm (W) X 810mm (L) x 160mm (B)' => 'ECOTACT SUPERVERT 40 545mm (W) X 810mm (L) x 160mm (B)',
    'Ecotact Sterile 15 400mm(W) x 600mm(L)' => 'Ecotact Stérile 15 400mm(W) x 600mm(L)',
    'Ecotact Sterile 7  300mm(W) x 500mm(L)' => 'Ecotact Stérile 7  300mm(W) x 500mm(L)',
    '1050mm (W) x 1050mm (L) x 1200mm (H) Top Spout- 400mm' => '1050mm (W) x 1050mm (L) x 1200mm (H) Bec supérieur- 400mm',
    'Other' => 'Autre',
    'SUPERGREEN 40 545mm (W) X 810mm (L) x 160mm (B)' => 'SUPERVERT 40 545mm (W) X 810mm (L) x 160mm (B)',
    '6080mm (L) X 2400mm (W) X 2400 mm (H)' => '6080mm (L) X 2400mm (W) X 2400 mm (H)',
    'Ecotact 1T 1050mm (W) x 1050mm (L) x 1200mm (H)' => 'Ecotact 1T 1050mm (W) x 1050mm (L) x 1200mm (H)',
    'Ecotact 1.5T Customized' => 'Ecotact 1.5T Customized',
    'Ecotact 2T Customized' => 'Ecotact 2T Customized',
    '360mm (L) x 295mm (W) x 435mm (H)' => '360mm (L) x 295mm (W) x 435mm (H)',
    '204mm (L) X 4.8mm (W)' => '204mm (L) X 4.8mm (W)',
    '545mm (W) X 810mm (L) x 160mm (B)' => '545mm (W) X 810mm (L) x 160mm (B)',

    'E' => 'Entrez la taille personnalisée:',
];


